/**HEADER********************************************************************
* 
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved                       
*
*************************************************************************** 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
*END************************************************************************/

#include "nand_memory.h"
#include "yaffsfs.h"
#include "yaffs_guts.h"
#include "yaffs_ecc.h"
#include "yaffs_trace.h"

int g_StartBlock;
int g_EndBlock;

unsigned int yaffs_trace_mask = 
    YAFFS_TRACE_ERROR |
    //YAFFS_TRACE_MOUNT |
    //YAFFS_TRACE_BAD_BLOCKS |
    //YAFFS_TRACE_CHECKPOINT |
    //YAFFS_TRACE_ALWAYS |
    0;

static int yaffs_nand_drv_WriteChunk(struct yaffs_dev *dev, int nand_chunk,
				   const u8 *data, int data_len,
				   const u8 *oob, int oob_len)
{
	if(!data || !oob)
	{
		NAND_Print("data or oob buffer is NULL, failed!!!\n");
		return YAFFS_FAIL;
	}
	
	u8 *buffer = NULL;
	buffer = kmalloc(dev->param.spare_bytes_per_chunk, 0);
	if(buffer == NULL)
	{
		NAND_Print("malloc spare buffer failed!\n");
		return YAFFS_FAIL;
	}
	memset(buffer, 0xff, dev->param.spare_bytes_per_chunk);
	
#if ! BSPCFG_ENABLE_NFC_ECC
	u8 *e;
	int i;
	for(i = 0, e = buffer + 2; i < dev->param.total_bytes_per_chunk; i+=256, e+=3)
	{
		yaffs_ecc_calc(data + i, e);
	}
#endif
	memcpy(buffer + 26, oob, oob_len);
	
	uint32_t result = nand_drv_write(Nand_fd, data, buffer, nand_chunk);
	if(result != NANDFLASHERR_NO_ERROR)
	{
        kfree(buffer);
	    return YAFFS_FAIL;
	}
	
    kfree(buffer);
	return YAFFS_OK;
}

static int yaffs_nand_drv_ReadChunk(struct yaffs_dev *dev, int nand_chunk,
				   u8 *data, int data_len,
				   u8 *oob, int oob_len,
				   enum yaffs_ecc_result *ecc_result_out)
{
    enum yaffs_ecc_result ecc_result;
	int i;
	u8 *e;
	u8 read_ecc[3];
	u8 *buffer;
	int ret;
	
	buffer = kmalloc(dev->param.spare_bytes_per_chunk, 0);
	if(buffer == NULL)
	{
		NAND_Print("malloc spare buffer failed!\n");
		return YAFFS_FAIL;
	}

	uint32_t result = nand_drv_read(Nand_fd, data, buffer, nand_chunk);
	if(result != NANDFLASHERR_NO_ERROR)
	{
		if(ecc_result_out)
		{
		    *ecc_result_out = YAFFS_ECC_RESULT_UNKNOWN;
		}
        kfree(buffer);
		return YAFFS_FAIL;
	}
	
	if(oob)
	{
		memcpy(oob, buffer + 26, oob_len);
	}
	ecc_result = YAFFS_ECC_RESULT_NO_ERROR;
#if ! BSPCFG_ENABLE_NFC_ECC
	if(data)
	{
	    for(i = 0, e = buffer + 2; i < dev->param.total_bytes_per_chunk; i+=256, e+=3)
		{
		    yaffs_ecc_calc(data + i, read_ecc);
			ret = yaffs_ecc_correct(data + i, e, read_ecc);
			if(ret < 0)
			{
				ecc_result = YAFFS_ECC_RESULT_UNFIXED;
			}
			else if( ret > 0 && ecc_result == YAFFS_ECC_RESULT_NO_ERROR)
			{
			    ecc_result = YAFFS_ECC_RESULT_FIXED;
			}
		}
	}
#endif
	
	if(ecc_result_out)
	{
	    *ecc_result_out = ecc_result;
	}
	
    kfree(buffer);
	return YAFFS_OK;
}

static int yaffs_nand_drv_EraseBlock(struct yaffs_dev *dev, int block_no)
{
    uint32_t result;
	
	result = nand_drv_block_erase(Nand_fd, block_no);
	if(result != NANDFLASHERR_NO_ERROR)
	{
	    return YAFFS_FAIL;
	}
	
	return YAFFS_OK;
}

static int yaffs_nand_drv_MarkBad(struct yaffs_dev *dev, int block_no)
{
    uint32_t result;
	result = nand_drv_mark_block_as_bad(Nand_fd, block_no);
	
	if(result != NANDFLASHERR_NO_ERROR)
	{
	    return YAFFS_FAIL;
	}
	
	return YAFFS_OK;
}

static int yaffs_nand_drv_CheckBad(struct yaffs_dev *dev, int block_no)
{
    uint32_t result;
	result = nand_drv_check_block(Nand_fd, block_no);
	
	if(result != NANDFLASHERR_BLOCK_NOT_BAD)
	{
        //nand_drv_block_erase_force(Nand_fd, block_no);
	    return YAFFS_FAIL;
	}
	
	return YAFFS_OK;
}

static int yaffs_nand_drv_Initialise(struct yaffs_dev *dev)
{
    return YAFFS_OK;
}

static int yaffs_nand_drv_Deinitialise(struct yaffs_dev *dev)
{
    return YAFFS_OK;
}

int yaffs_nand_install(const char *dev_name, int n_blocks)
{
    struct yaffs_dev *dev;
    struct yaffs_param *param;
	struct yaffs_driver *drv;

    dev = kmalloc(sizeof(struct yaffs_dev), 0);
	if(dev == NULL)
	{
		goto FAIL;
	}
	memset(dev, 0, sizeof(struct yaffs_dev));

    param = &dev->param;
	param->name = dev_name;
	param->total_bytes_per_chunk = 2048;
    param->spare_bytes_per_chunk = 64;
	param->chunks_per_block = 64;
	param->n_reserved_blocks = 5;
	param->start_block = 0; // First block
	param->end_block = n_blocks - 1; // Last block
	param->is_yaffs2 = 1;
	param->use_nand_ecc = 0;
	param->n_caches = 10;
    //param->wide_tnodes_disabled = 1;
    
    g_StartBlock = param->start_block;
    g_EndBlock = param->end_block;

	drv = &dev->drv;
	drv->drv_write_chunk_fn = yaffs_nand_drv_WriteChunk;
    drv->drv_read_chunk_fn = yaffs_nand_drv_ReadChunk;
	drv->drv_erase_fn = yaffs_nand_drv_EraseBlock;
	drv->drv_mark_bad_fn = yaffs_nand_drv_MarkBad;
	drv->drv_check_bad_fn = yaffs_nand_drv_CheckBad;
	drv->drv_initialise_fn = yaffs_nand_drv_Initialise;
	drv->drv_deinitialise_fn = yaffs_nand_drv_Deinitialise;

    /* The yaffs device has been configured, install it into yaffs */
	yaffs_add_device(dev);

    return YAFFS_OK;
FAIL:
    kfree(dev);
	return YAFFS_FAIL;
}

int yaffs_nand_uninstall(const char *dev_name)
{
    void *dev = yaffs_getdev(dev_name);
    if(dev != NULL)
    {
        kfree(dev);
        dev = NULL;
    }
    return YAFFS_OK;
}

int yaffs_start_up()
{
    static int start_up_called = 0;
    if(start_up_called)
	{
		return YAFFS_OK;
	}
	start_up_called = 1;

	/* inatall device */
	int ret = yaffs_nand_install("nand", 900);
    if(ret != YAFFS_OK )
    {
        return YAFFS_FAIL;
    }
    
    ret = nand_drv_open();
    if(ret != NANDFLASHERR_NO_ERROR)
    {
        return YAFFS_FAIL;
    }
	
	return YAFFS_OK;
}

int yaffs_end_up()
{
    static int end_up_called = 0;
    if(end_up_called)
	{
		return YAFFS_OK;
	}
	end_up_called = 1;
    
    int ret = yaffs_nand_uninstall("nand");
    if(ret != YAFFS_OK )
    {
        return YAFFS_FAIL;
    }
    
    ret = nand_drv_close();
    if(ret != NANDFLASHERR_NO_ERROR)
    {
        return YAFFS_FAIL;
    }
	
	return YAFFS_OK;
}
