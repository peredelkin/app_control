/**HEADER********************************************************************
*
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved
*
***************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: nand_memory.c$
* $Version : 1.0.0.0$
* $Date    : Jan-3-2014$
*
* Comments:
*
*   This file contains the functions which write and read the NAND memories
*   using the NAND driver in polled mode.
*
*END************************************************************************/

#include <mqx.h>
#include <bsp.h>
#include "nand_memory.h"

MQX_FILE_PTR Nand_fd = NULL;

uint32_t nand_drv_open()
{
    Nand_fd = fopen(NAND_FLASH_NAME, NULL);
    if(NULL == Nand_fd)
    {
        NAND_Print("nand_drv_open(): failed to open Nand driver!\n");
        return NANDFLASHERR_INFO_STRUC_MISSING;
    }
    NAND_Print("nandflash_open: NAND Flash device %s opened\n", NAND_FLASH_NAME);
    return NANDFLASHERR_NO_ERROR;
}

uint32_t nand_drv_close()
{
    fclose(Nand_fd);
    return NANDFLASHERR_NO_ERROR;
}

uint32_t nand_drv_read_id(MQX_FILE_PTR nand_fd, uint32_t *devId)
{
	uint32_t Id = 0;
	_mqx_int result;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_GET_ID, &Id);
	if(result != MQX_OK)
	{
		NAND_Print("Read the ID of Nandflash failed!\n");
		return NANDFLASHERR_INFO_STRUC_MISSING;
	}
	else
	{
		NAND_Print("The ID of Nandflash is 0x%X!\n", Id);
		*devId = Id;
		return NANDFLASHERR_NO_ERROR;
	}
}
/*
uint_32 nand_drv_chip_erase(MQX_FILE_PTR nand_fd)
{
	_mqx_int result;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_ERASE_CHIP, NULL);
	if(result != MQX_OK)
	{
		NAND_Print(" Erase the entire nand chip failed\n");
		return NANDFLASHERR_ERASE_FAILED;
	}
	else
	{
		NAND_Print(" Erase the entire nand chip successfully\n");
		return NANDFLASHERR_NO_ERROR;
	}
}
*/
uint32_t nand_drv_block_erase(MQX_FILE_PTR nand_fd, _mem_size blockNo)
{
	_mqx_int result;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_ERASE_BLOCK, (void *)blockNo);
	if(result != MQX_OK)
	{
		NAND_Print(" Erase the block[%d] failed\n", blockNo);
		return NANDFLASHERR_ERASE_FAILED;
	}
	else
	{
		//NAND_Print(" Erase the block[%d] successfully\n", blockNo);
		return NANDFLASHERR_NO_ERROR;
	}
}

uint32_t nand_drv_block_erase_force(MQX_FILE_PTR nand_fd, _mem_size blockNo)
{
    _mqx_int result;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_ERASE_BLOCK_FORCE, (void *)blockNo);
	if(result != MQX_OK)
	{
		NAND_Print(" Forced Erase the block[%d] failed\n", blockNo);
		return NANDFLASHERR_ERASE_FAILED;
	}
	else
	{
		//NAND_Print(" Erase the block[%d] successfully\n", blockNo);
		return NANDFLASHERR_NO_ERROR;
	}
}

uint32_t nand_drv_read(MQX_FILE_PTR nand_fd, unsigned char * read_data_buffer, unsigned char * read_spare_buffer, _mem_size pageNums)
{
	_mqx_int result;
	//IO_NANDFLASH_STRUCT_PTR handle_ptr = (IO_NANDFLASH_STRUCT_PTR)(nand_fd->DEV_PTR->DRIVER_INIT_PTR);
	NANDFLASH_PAGE_DATA_STRUCT pageData;
	pageData.PAGE_NUM = pageNums;
    pageData.PAGE_DATA = read_data_buffer;
    pageData.PAGE_SPARE = read_spare_buffer;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_READ_ONE_FULL_PAGE, &pageData);
    if(result != MQX_OK)
    {
        NAND_Print(" Read the page[%d] failed\n", pageNums);
        return NANDFLASHERR_READ_FAILED;
    }
    else
    {
        return NANDFLASHERR_NO_ERROR;
    }
}

uint32_t nand_drv_write(MQX_FILE_PTR nand_fd, const unsigned char *write_data_buffer, const unsigned char * write_spare_buffer, _mem_size pageNums)
{
	_mqx_int result;
	//IO_NANDFLASH_STRUCT_PTR handle_ptr = (IO_NANDFLASH_STRUCT_PTR)(nand_fd->DEV_PTR->DRIVER_INIT_PTR);
	NANDFLASH_PAGE_DATA_STRUCT pageData;
	pageData.PAGE_NUM = pageNums;
    pageData.PAGE_DATA = (unsigned char *)write_data_buffer;
    pageData.PAGE_SPARE = (unsigned char *)write_spare_buffer;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_WRITE_ONE_FULL_PAGE, &pageData);
    if(result != MQX_OK)
    {
        NAND_Print(" Write the page[%d] failed\n", pageNums);
        return NANDFLASHERR_WRITE_FAILED;
    }
    else
    {
        return NANDFLASHERR_NO_ERROR;
    }
}

uint32_t nand_drv_mark_block_as_bad(MQX_FILE_PTR nand_fd, _mem_size blockNo)
{
    _mqx_int result;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_MARK_BLOCK_AS_BAD, (void *)blockNo);
	if(result != MQX_OK)
	{
		NAND_Print(" Mark the block[%d] as bad failed\n", blockNo);
		return NANDFLASHERR_ERASE_FAILED;
	}
	else
	{
        NAND_Print(" Mark the block[%d] as bad\n", blockNo);
		return NANDFLASHERR_NO_ERROR;
	}
}

uint32_t nand_drv_check_block(MQX_FILE_PTR nand_fd, _mem_size blockNo)
{
	_mqx_int result;
	
	result = ioctl(nand_fd, NANDFLASH_IOCTL_CHECK_BLOCK, (void *)blockNo);
	if(result == NANDFLASHERR_BLOCK_BAD)
	{
		NAND_Print(" block[%d] is bad\n", blockNo);
		return NANDFLASHERR_BLOCK_BAD;
	}
	else
	{
        //NAND_Print(" block[%d] is good\n", blockNo);
		return NANDFLASHERR_BLOCK_NOT_BAD;
	}
}

