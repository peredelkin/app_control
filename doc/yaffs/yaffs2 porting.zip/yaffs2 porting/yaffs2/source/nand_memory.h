#ifndef __nand_memory_h__
#define __nand_memory_h__
/**HEADER********************************************************************
* 
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved                       
*
*************************************************************************** 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: nand_memory.h$
* $Version : 1.0.0.0$
* $Date    : Jan-3-2014$
*
* Comments:
*
*   This file contains definitions for the nand memory example.
*
*END************************************************************************/

#include <mqx.h>
#include <bsp.h> 
#include <fio.h>
#include "Nandflash.h"

#define NAND_FLASH_NAME         "nandflash:"

/* Funtion prototypes */
uint32_t nand_drv_open();
uint32_t nand_drv_close();
uint32_t nand_drv_read_id(MQX_FILE_PTR nand_fd, uint32_t *devId);
uint32_t nand_drv_block_erase(MQX_FILE_PTR nand_fd, _mem_size blockNo);
uint32_t nand_drv_block_erase_force(MQX_FILE_PTR nand_fd, _mem_size blockNo);
uint32_t nand_drv_read(MQX_FILE_PTR nand_fd, unsigned char * read_data_buffer, unsigned char * read_spare_buffer, _mem_size pageNums);
uint32_t nand_drv_write(MQX_FILE_PTR nand_fd, const unsigned char *write_data_buffer, const unsigned char * write_spare_buffer, _mem_size pageNums);
uint32_t nand_drv_mark_block_as_bad(MQX_FILE_PTR nand_fd, _mem_size blockNo);
uint32_t nand_drv_check_block(MQX_FILE_PTR nand_fd, _mem_size blockNo);

#ifdef NAND_DEBUG
#define NAND_Print(fmt, args...)     printf(fmt, ##args)
#else
#define NAND_Print(fmt, args...)
#endif 

extern MQX_FILE_PTR Nand_fd;
extern int g_StartBlock;
extern int g_EndBlock;

#endif
