/**HEADER********************************************************************
* 
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved                       
*
*************************************************************************** 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: test_main.c$
* $Version : 1.0.0.0$
* $Date    : Jun-12-2014$
*
* Comments:
*
*   This file contains the source for yaffs basic test.
*
*END************************************************************************/

#include <mqx.h>
#include <bsp.h> 
#include <fio.h>
#include "yaffsfs.h"
#include "yaffs_guts.h"
#include "nand_memory.h"


#if ! BSPCFG_ENABLE_IO_SUBSYSTEM
#error This application requires BSPCFG_ENABLE_IO_SUBSYSTEM defined non-zero in user_config.h. Please recompile BSP with this option.
#endif


#ifndef BSP_DEFAULT_IO_CHANNEL_DEFINED
#error This application requires BSP_DEFAULT_IO_CHANNEL to be not NULL. Please set corresponding BSPCFG_ENABLE_TTYx to non-zero in user_config.h and recompile BSP with this option.
#endif

#define INIT_TASK_ID    10
extern void Init_Task(uint_32);
/* 
 * Set all the task as MQX_AUTO_START_TASK.
 * TODO: Add a shell task.
 */
const TASK_TEMPLATE_STRUCT  MQX_template_list[] = 
{ 
    /* Task Index,   		Function,   	    Stack,  Priority, Name,     Attributes,          Param, Time Slice */
    {INIT_TASK_ID,          Init_Task,          5000,   8,    "initTask",    MQX_AUTO_START_TASK, 0,     0 },
    { 0 }
};

#define TEST_DIR_NUMBERS            3
#define	TEST_FILE_NUMBERS			30
#define	TEST_FILE_SIZE				1024
#define FILE_NAME_BUFFER_SIZE       48

_mem_pool_id ext_sram_pool = NULL;

void dump_dir(const char *dir_name)
{
    yaffs_DIR *d;
	struct yaffs_dirent *de;
	struct yaffs_stat s;
	char str[100];
	
	d = yaffs_opendir(dir_name);
	if(!d)
	{
	    printf("Open directory %s failed!\n", dir_name);
		return;
	}
	
	while( (de = yaffs_readdir(d)) != NULL )
	{
	    sprintf(str,"%s/%s",dir_name, de->d_name);
		yaffs_lstat(str, &s);
		printf("%s is ", str);
		switch(s.st_mode & S_IFMT)
		{
		case S_IFREG:
		    printf("data file, ");
		    break;
		case S_IFDIR:
		    printf("directory, ");
		    break;
		case S_IFLNK:
		    printf("symlink --> ");
			if(yaffs_readlink(str, str, 100) < 0)
			    printf("no alias, ");
			else
			    printf("\"%s\", ", str);
		    break;
		default:
		    printf("unkown type, ");
		    break;
		}
		printf("size is %d.\n", s.st_size);
	}
	
	yaffs_closedir(d);
}

void yaffs_main(void)
{
	int i, j, k;
	unsigned char *buf;
	unsigned char *rdbuf;
	unsigned char filename[FILE_NAME_BUFFER_SIZE];
	int result;
	int fHandle;
    
    buf = (unsigned char *)kmalloc(TEST_FILE_SIZE, 0);
    rdbuf = (unsigned char *)kmalloc(TEST_FILE_SIZE, 0);
    if(!buf || !rdbuf)
    {
        printf("malloc buf or rdbuf failed!\n");
        return;
    }
	
	for(i=0; i<TEST_FILE_SIZE; i++)
	{
		buf[i] = i % 256;
	}
	
	result = yaffs_start_up();
	if(result != YAFFS_OK)
	{
	    printf("Start yaffs2 failed!\n");
		return;
	}
	else
	{
	    printf("Start yaffs2 successfully.\n");
	}
#if 0    
    uchar_ptr data_buf;
    uchar_ptr spare_buf;
    data_buf = kmalloc(2048, 0);
    spare_buf = kmalloc(64, 0);
    if(!data_buf || !spare_buf)
    {
        printf("malloc buffer failed!\n");
        kfree(data_buf);
        kfree(spare_buf);
        return;
    }
    for(i=0; i<2048; i++)
    {
        data_buf[i] = (i+1) % 256;
    }
    spare_buf[0] = 0xFF;
    for(j=1; j<64; j++)
    {
        spare_buf[j] = j;
    }
    result = nand_drv_block_erase_force(Nand_fd, 1);
    if(result != NANDFLASHERR_NO_ERROR)
    {
        printf("erase block failed!\n");
        return;
    }
    result = nand_drv_write(Nand_fd, data_buf, spare_buf, 68);
    if(result != NANDFLASHERR_NO_ERROR)
    {
        printf("write one page failed!\n");
        return;
    }
    memset(data_buf, 0, 2048);
    memset(spare_buf, 0, 64);
    result = nand_drv_read(Nand_fd, data_buf, spare_buf, 68);
    if(result != NANDFLASHERR_NO_ERROR)
    {
        printf("read one page failed!\n");
        return;
    }
    for(i=0; i<2048; i++)
    {
        if( data_buf[i] != ((i+1)%256) )
        {
            printf("data verify failed!\n");
            return;
        }
    }
    if(spare_buf[0] != 0xFF)
    {
        printf("spare 1 verify failed!\n");
        return;
    }
    for(j=1; j<64; j++)
    {
        if(spare_buf[j] != j)
        {
            printf("spare 2-64 verify failed!\n");
            return;
        }
    }
    
    printf("erase-write-read-verify ok.\n");
    
    kfree(data_buf);
    kfree(spare_buf);
    return;
#endif
    //nand_drv_check_block(Nand_fd, 1);
    //nand_drv_block_erase_force(Nand_fd, 1);
    //nand_drv_check_block(Nand_fd, 1);
    result = yaffs_format("/nand", 0, 0, 0);
    if(result != 0)
    {
        printf("Format yaffs2 device failed!\n");
    }
    else
    {
        printf("Format yaffs2 device successfully.\n");
    }
    
	result = yaffs_mount("/nand");
	if(result != 0)
	{
	    printf("Mount yaffs2 device failed!\n");
		return;
	}
	else
	{
	    printf("Mount %s successfully\n", "/nand");
	}
#if 0	
	for(j=1; j<=TEST_DIR_NUMBERS; j++)
	{
        memset(filename, 0, FILE_NAME_BUFFER_SIZE);
	    sprintf(filename, "/nand/dir%d", j);
		result = yaffs_mkdir(filename, S_IREAD| S_IWRITE);
		if(result != 0)
	    {
	        printf("Make directory %s failed!\n", filename);
	    	return;
	    }
		else
		{
		    printf("Make directory %s successfully.\n", filename);
		}
	}
	
	for(j=1; j<=TEST_DIR_NUMBERS; j++)
	{
		for(i=0; i<TEST_FILE_NUMBERS; i++)
		{
            memset(filename, 0, FILE_NAME_BUFFER_SIZE);
            sprintf(filename, "/nand/dir%d/file%d.txt", j, i);
			//Open
			fHandle = yaffs_open(filename, O_RDWR | O_CREAT | O_TRUNC, S_IREAD| S_IWRITE);
			if(fHandle == -1)
			{
				printf("Open %s failed!\n", filename);
			}
			else
			{
			    printf("Open(Create) %s successfully.\n", filename);
			    //Write
				result = yaffs_write(fHandle, buf, TEST_FILE_SIZE);
				if(result == -1)
				{
					printf("Write %s failed!\n", filename);
				}
				else
				{
					if(result < TEST_FILE_SIZE)
					{
						printf("Should write %d, Actually written %d.\n", TEST_FILE_SIZE, result);
					}
					printf("Write %s successfully.\n", filename);
				}
				//Read and Verify the file data
                result = yaffs_lseek(fHandle, 0, SEEK_SET);
                if(result == -1)
                {
                    printf("Seek file %s failed!\n", filename);
                }
				result = yaffs_read(fHandle, rdbuf, TEST_FILE_SIZE);
				if(result == -1)
				{
				    printf("Read %s failed!\n", filename);
				}
				else
				{
				    if(result < TEST_FILE_SIZE)
					{
					    printf("Should read %d, Actually read %d.\n", TEST_FILE_SIZE, result);
					}
					for(k=0; k<result; k++)
					{
					    if(rdbuf[k] != (k % 256))
						{
						    printf("file data verified failed, should be %d, Actually %d.\n", k, rdbuf[k]);
							break;
						}
					}
					printf("Read&Verify %s successfully.\n", filename);
				}
				//Close
				result = yaffs_close(fHandle);
				if(result != 0)
				{
					printf("Close %s failed!\n", filename);
				}
				else
				{
				    printf("Close %s successfully.\n", filename);
				}
			}
		}
	}
	
	dump_dir("/nand");
	for(j=1; j<=TEST_DIR_NUMBERS; j++)
	{
        memset(filename, 0, FILE_NAME_BUFFER_SIZE);
	    sprintf(filename, "/nand/dir%d", j);
		dump_dir(filename);
	}
	
	for(j=1; j<=TEST_DIR_NUMBERS; j++)
	{
	    for(i=0; i<TEST_FILE_NUMBERS; i++)
		{
            memset(filename, 0, FILE_NAME_BUFFER_SIZE);
            sprintf(filename, "/nand/dir%d/file%d.txt", j, i);
			result = yaffs_unlink(filename);
		    if(result != 0)
		    {
		        printf("Delete %s failed!\n", filename);
		    }
			else
			{
			    printf("Delete %s successfully.\n", filename);
			}
        }
	}
#endif
    
    kfree(buf);
    kfree(rdbuf);
}

void test_1M_file(unsigned char *wr_buf, unsigned char *rd_buf)
{
    printf("\r\n\r\n*************************************************\r\n");
    printf("* write-read-verify 1MB to a file, then poweroff-on test\r\n");
    printf("*********************************************************\r\n");
    
    unsigned char *filename = "/nand/file_1m.dat";
    int i;
    int loopCount = (1024*1024)/TEST_FILE_SIZE;
    int fHandle;
    int result;
    yaffs_stat file_st;
    
    printf("Last file, PowerOff-PowerOn, check the file\r\n");
    dump_dir("/nand");
    //open
    fHandle = yaffs_open(filename, O_RDWR, S_IREAD| S_IWRITE);
	if(fHandle == -1)
	{
		printf("Cannot find file \"%s\".\r\n", filename);
	}
    else
    {
        result = yaffs_lstat(filename, &file_st);
        if(result == -1)
        {
            printf("yaffs_lstat(%s) failed!\r\n", filename);
            return;
        }
        printf("File \"%s\" size is %d.\r\n", file_st.st_size);
    }
    
    //open
    fHandle = yaffs_open(filename, O_RDWR | O_CREAT | O_TRUNC, S_IREAD| S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open %s failed!\n", filename);
        return;
	}
    printf("Open(Create) %s successfully.\n", filename);
    
    //write
    for(i=0; i<loopCount; i++)
    {
        result = yaffs_write(fHandle, wr_buf, TEST_FILE_SIZE);
        if(result == -1)
		{
			printf("Write %s failed!\n", filename);
            return;
		}
		else
		{
			if(result < TEST_FILE_SIZE)
			{
				printf("[Loop:%d]Should write %d, Actually written %d.\n", i, TEST_FILE_SIZE, result);
                return;
			}
		}
    }
    printf("Write %s successfully.\n", filename);
    
    dump_dir("/nand");
    
    //read-verify
    result = yaffs_lseek(fHandle, 0, SEEK_SET);
    if(result == -1)
    {
        printf("Seek file %s failed!\n", filename);
    }
    for(i=0; i<loopCount; i++)
    {
    }
}

void Init_Task(uint_32 initial_data)
{
    printf("\n\n***************************************************\n");
    printf("\tYaffs2 filesystem test\n");
    printf("*******************************************************\n\n");
    
    ext_sram_pool = _mem_create_pool(BSP_EXTERNAL_MRAM_RAM_BASE,
            (_mem_size)BSP_EXTERNAL_MRAM_RAM_SIZE);

    yaffs_main();
    
    int result = yaffs_unmount("/nand");
    if(result != 0)
    {
        printf("Unmount /nand failed!\n");
    }
    else
    {
        printf("Unmount /nand successfully.\n");
    }
    
    result = yaffs_end_up("nand");
    if(result != YAFFS_OK)
    {
        printf("End yaffs2 failed!\n");
    }
    else
    {
        printf("End yaffs2 successfully.\n");
    }
    
    printf("\n***Yaffs2 test end!***\n");
    
    _task_block();
     
    _mqx_exit(0);
}
/* EOF */
