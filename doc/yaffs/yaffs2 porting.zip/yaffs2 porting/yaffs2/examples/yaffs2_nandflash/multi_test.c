/**HEADER********************************************************************
* 
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved                       
*
*************************************************************************** 
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR 
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES 
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
* THE POSSIBILITY OF SUCH DAMAGE.
*
**************************************************************************
*
* $FileName: test_main.c$
* $Version : 1.0.0.0$
* $Date    : Jun-12-2014$
*
* Comments:
*
*   This file contains the source for yaffs2 test.
*
*END************************************************************************/

#include <mqx.h>
#include <bsp.h> 
#include <fio.h>
#include "shell.h"
#include "yaffsfs.h"
#include "yaffs_guts.h"
#include "nand_memory.h"

#if ! BSPCFG_ENABLE_IO_SUBSYSTEM
#error This application requires BSPCFG_ENABLE_IO_SUBSYSTEM defined non-zero in user_config.h. Please recompile BSP with this option.
#endif

#ifndef BSP_DEFAULT_IO_CHANNEL_DEFINED
#error This application requires BSP_DEFAULT_IO_CHANNEL to be not NULL. Please set corresponding BSPCFG_ENABLE_TTYx to non-zero in user_config.h and recompile BSP with this option.
#endif

#if ! SHELLCFG_USES_MFS
#error This application requires SHELLCFG_USES_MFS defined non-zero in user_config.h. Please recompile libraries with this option.
#endif

#define MULTI_TEST_TASK_ID    10
extern void Multi_Test_Task(uint32_t);

#define MOUNT_POINT	"/nand"
#define MAX_ALLOC_BUFFER_LENGTH		256

extern _mem_pool_id ext_sram_pool;

const TASK_TEMPLATE_STRUCT  MQX_template_list[] = 
{ 
    /* Task Index,   		Function,   	    Stack,  Priority, Name,              Attributes,          Param, Time Slice */
    {MULTI_TEST_TASK_ID,    Multi_Test_Task,    10240,   8,        "MultiTestTask",   MQX_AUTO_START_TASK, 0,     0 },
    { 0 }
};

int32_t Function_format(int argc, char * argv[]);
int32_t Function_erase_block(int argc, char * argv[]);
int32_t Function_mount(int argc, char * argv[]);
int32_t Function_unmount(int argc, char * argv[]);
int32_t Function_get_free_space(int argc, char * argv[]);
int32_t Function_make_directory(int argc, char * argv[]);
int32_t Function_delete_directory(int argc, char * argv[]);
int32_t Function_make_file(int argc, char * argv[]);
int32_t Function_read_file(int argc, char * argv[]);
int32_t Function_delete_file(int argc, char * argv[]);
int32_t Function_make_files(int argc, char * argv[]);
int32_t Function_dump_directory(int argc, char * argv[]);
int32_t Function_max_data_in_a_file(int argc, char * argv[]);
int32_t Function_max_files_with_size(int argc, char * argv[]);
int32_t Function_1kb_files_test(int argc, char * argv[]);
int32_t Function_one_1kb_file_test(int argc, char * argv[]);
int32_t Function_one_file_multi_times_perf(int argc, char * argv[]);
int32_t Function_multi_files_one_time_perf(int argc, char * argv[]);
int32_t Function_command_description(int argc, char * argv[]);

const SHELL_COMMAND_STRUCT Shell_commands[] = 
{
	{ "format", Function_format },
    { "erase", Function_erase_block },
	{ "mount", Function_mount },
	{ "unmount", Function_unmount },
	{ "free", Function_get_free_space },
	{ "mkdir", Function_make_directory },
	{ "rmdir", Function_delete_directory },
	{ "mkfile", Function_make_file },
	{ "rdfile", Function_read_file },
    { "rmfile", Function_delete_file },
    { "mkfiles", Function_make_files },
    { "lsdir", Function_dump_directory },
	{ "maxdata", Function_max_data_in_a_file },
    { "maxfiles", Function_max_files_with_size },
    { "max1kfiles", Function_1kb_files_test },
    { "one1kfile", Function_one_1kb_file_test },
    { "perf1", Function_one_file_multi_times_perf },
    { "perf2", Function_multi_files_one_time_perf },
    { "help", Function_command_description },
	{ NULL,        NULL } 
};

const unsigned char *Command_Description[] = 
{
	"Format the entire flash.",
    "Erase a block, Usage: erase [-f] blknum.",
	"Mount the yaffs2 device.",
    "Unmount the yaffs2 device.",
    "Get the current freespace.",
    "Make a directory, Usage: mkdir dirname.",
    "Delete a directory, Usage: rmdir dirname.",
    "Make a file, Usage: mkfile filename filesize.",
    "Read and verify the file made by \"mkfile\", Usage: rdfile filename.",
    "Delete a file, Usage: rmfile filename.",
    "Make multiple files, Usage: mkfiles filesize filenums.",
    "list the items of the directory, Usage: lsdir dirname.",
    "Test the max data size in a file accepted by yaffs2.",
    "Test the max file nums accepted with data size, Usage: maxfiles filesize.",
    "Fill files with 1KB as much as possible, check the capacity left, then delete half of them, check the capacity left.",
    "Write a 1KB file, then append 1KB, modify 1KB content, check content.",
    "Test the performance with one file multiple times, Usage: perf1 filesize repeats.",
    "Test the performance with multiple files one time, Usage: perf2 filesize filenums.",
	"Get the description of all commands."
};

int create_file_with_size(const char *filename, int filesize)
{
    int result, i, retVal;
	int fHandle;
	unsigned char *wr_buf = NULL;
    int buf_len;
	
	if(!filename || filesize <= 0)
    {
        printf("filename or filesize is error!\r\n");
        return -1;
    }
	
	fHandle = yaffs_open(filename, O_RDWR | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open \"%s\" failed!\r\n", filename);
		return -1;
	}
	
	int loopCount, leftBytes;
	loopCount = filesize / MAX_ALLOC_BUFFER_LENGTH;
	leftBytes = filesize % MAX_ALLOC_BUFFER_LENGTH;
	
    if(filesize < MAX_ALLOC_BUFFER_LENGTH)
	{
		buf_len = filesize;
	}
	else
	{
		buf_len = MAX_ALLOC_BUFFER_LENGTH;
	}
    
	wr_buf = (unsigned char *)kmalloc(buf_len, 0);
	if(!wr_buf)
	{
		printf("malloc wr_buf failed!\r\n");
        retVal = -1;
		goto RET;
	}
	for(i=0; i<buf_len; i++)
	{
		wr_buf[i] = (i % 256);
	}
	
	for(i=0; i<loopCount; i++)
	{
		result = yaffs_write(fHandle, wr_buf, MAX_ALLOC_BUFFER_LENGTH);
		if(result == -1)
		{
			printf("[Loop:%d]Write %s failed!\n", i, filename);
            retVal = -1;
			goto RET;
		}
		else
		{
			if(result < MAX_ALLOC_BUFFER_LENGTH)
			{
				printf("[Loop:%d]Should write %d, Actually written %d.\n", i, MAX_ALLOC_BUFFER_LENGTH, result);
			}
		}
	}
	if(leftBytes != 0)
	{
		result = yaffs_write(fHandle, wr_buf, leftBytes);
		if(result == -1)
		{
			printf("[Last]Write %s failed!\n", filename);
            retVal = -1;
			goto RET;
		}
		else
		{
			if(result < leftBytes)
			{
				printf("[Last]Should write %d, Actually written %d.\n", leftBytes, result);
			}
		}
	}
	printf("Write \"%s\" successfully.\n", filename);
    retVal = 0;
	
RET:
	kfree(wr_buf);
	result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("Close \"%s\" failed!\r\n", filename);
	}
	else
	{
	    printf("Close \"%s\" successfully.\r\n", filename);
	}
    
    return retVal;
}

int append_file_with_size(const char *filename, int file_size)
{
    int fHandle;
	int result;
	unsigned char *wr_buf = NULL;
	int buf_len = 0;
	int i = 0;
    
    if(file_size < MAX_ALLOC_BUFFER_LENGTH)
	{
		buf_len = file_size;
	}
	else
	{
		buf_len = MAX_ALLOC_BUFFER_LENGTH;
	}
	wr_buf = (unsigned char *)kmalloc(buf_len, 0);
	if(NULL == wr_buf)
	{
		printf("Alloc wr_buf failed!\r\n");
		return -1;
	}
    for(i=0; i<buf_len; i++)
	{
		wr_buf[i] = i;
	}
    
    fHandle = yaffs_open(filename, O_RDWR|O_APPEND, S_IREAD|S_IWRITE);
    if (fHandle == -1) 
	{
        printf("Open\"%s\" failed!\r\n", filename);
		kfree(wr_buf);
        return -1;
    }
    
    int currentBytes = 0;
	while(file_size > 0)
	{
		if(file_size < buf_len)
		{
			currentBytes = file_size;
		}
		else
		{
			currentBytes = buf_len;
		}
		result = yaffs_write(fHandle, wr_buf, currentBytes);
		if(result != currentBytes)
		{
			printf("Wrote %d, should have been %d. size is %d\n",result,currentBytes,file_size);
			file_size = 0;
		}
		else
		{
			file_size -= currentBytes;
		}
	}

	kfree(wr_buf);
    yaffs_close(fHandle);

	return 0;
}

int verify_file_with_size(const char *filename, int offset, int file_size)
{
    int fHandle;
	int result;
	unsigned char *rd_buf;
	int buf_len;
	int i = 0;

	if(file_size < MAX_ALLOC_BUFFER_LENGTH)
	{
		buf_len = file_size;
	}
	else
	{
		buf_len = MAX_ALLOC_BUFFER_LENGTH;
	}
	rd_buf = (unsigned char *)kmalloc(buf_len, 0);
	if(NULL == rd_buf)
	{
		printf("Alloc rd_buf failed!\r\n");
		return -1;
	}

	fHandle = yaffs_open(filename, O_RDWR, S_IREAD|S_IWRITE);
    if (fHandle == -1) 
	{
        printf("Open \"%s\" failed!\r\n", filename);
		kfree(rd_buf);
        return -1;
    }
    
    yaffs_lseek(fHandle, offset, SEEK_SET);
    
    int currentBytes = 0;
	while(file_size > 0)
	{
		if(file_size < buf_len)
		{
			currentBytes = file_size;
		}
		else
		{
			currentBytes = buf_len;
			
		}
		result = yaffs_read(fHandle, rd_buf, currentBytes);
		if(result != currentBytes)
		{
			printf("Actual read %d, should read %d\r\n", result, currentBytes);
			file_size = 0;
		}
		else
		{
			file_size -= currentBytes;
			for(i=0; i<currentBytes; i++)
			{
				if(rd_buf[i] != i)
				{
					printf("Verify failed!, read byte %d, should %d\r\n", rd_buf[i], i);
					kfree(rd_buf);
					yaffs_close(fHandle);
					return -1;
				}
			}
		}
	}

	kfree(rd_buf);
	yaffs_close(fHandle);
    
    return 0;
}

int write_data_to_file(const char *filename, int offset, unsigned char *buf, int buf_size)
{
    int fHandle;
	int ret;
    int size;

    fHandle = yaffs_open(filename, O_RDWR, S_IREAD|S_IWRITE);
    if(fHandle == -1)
	{
        printf("Open \"%s\" failed!\r\n", filename);
        return -1;
    }
    
    ret = yaffs_lseek(fHandle, offset, SEEK_SET); 
	if(ret == -1)
	{
        printf("Seek file to %d failed!\r\n", offset);
        return -1;
    }
    
    size = yaffs_write(fHandle, buf, buf_size);
    if(size != buf_size)
	{
        printf("Wrote %d, should write %d\r\n", size, buf_size);
    }
    
    ret = yaffs_close(fHandle);
    if(ret == -1)
	{
        printf("Close \"%s\" failed!\r\n", filename);
        return -1;
    }
    
    return 0;
}

int read_data_from_file(char *filename, int offset, unsigned char *buf, int buf_size)
{
    int fHandle;
    int size;
	int ret;

    fHandle = yaffs_open(filename, O_RDWR, S_IREAD|S_IWRITE);
    if(fHandle == -1)
	{
        printf("Open \"%s\" failed!\r\n", filename);
        return -1;
    }

	ret = yaffs_lseek(fHandle, offset, SEEK_SET);
    if(ret == -1)
	{
        printf("Seek file to %d failed!\r\n", offset);
        return -1;
    }
    
    size = yaffs_read(fHandle, buf, buf_size);
    if(size != buf_size)
	{
        printf("Read %d, should read %d\r\n", size, buf_size);
    }
    
    ret = yaffs_close(fHandle);
    if(ret == -1)
	{
        printf("Close \"%s\" failed!\r\n", filename);
        return -1;
    }
    
    return 0;
}

int create_max_nums_files(uint32_t file_size)
{
    int file_num = 0;
    char name_buf[128] = { 0 };
    
    for (file_num = 0; ; ++file_num) 
    {
        sprintf(name_buf, "/nand/file%d.dat", file_num);
        if(create_file_with_size(name_buf, file_size) != 0) 
		{
			break;
		}
    }
    
    return file_num;
}

int32_t Function_format(int32_t argc, char * argv[])
{
	int result;
    int bForce = 0;
    int i;
    
	printf("Start formatting the entire flash...\r\n");
    
    if(strcmp(argv[1], "-f") == 0)
    {
        bForce = 1;
    }
    else
    {
        bForce = 0;
    }
	
    if(!bForce)
    {
        result = yaffs_format(MOUNT_POINT, 0, 0, 0);
        if(result != 0)
        {
            printf("Format yaffs2 device failed!\r\n");
        }
        else
        {
            printf("Format yaffs2 device successfully.\r\n");
        }
    }
	else
    {
        for(i=g_StartBlock; i<=g_EndBlock; i++)
        {
            nand_drv_block_erase_force(Nand_fd, i);
        }
        printf("Force format yaffs2 device.\r\n");
    }
	
    return 0;
}

int32_t Function_erase_block(int32_t argc, char * argv[])
{
    int bForce = 0;
    int block_num;
    
    if(argc < 2)
    {
        printf("please input block number.\r\n");
        return 0;
    }
    
    if(argc == 2)
    {
        if(strcmp(argv[1], "-f") == 0)
        {
            printf("please input block number.\r\n");
            return 0;
        }
        else
        {
            if( !Shell_parse_int_32(argv[1], &block_num) )
            {
                printf("block number is error.\r\n");
                return 0;
            }
            if(block_num <= 0)
            {
                printf("block number is error.\r\n");
                return 0;
            }
        }
    }
    else if(argc == 3)
    {
        if(strcmp(argv[1], "-f") == 0)
        {
            bForce = 1;
        }
        if( !Shell_parse_int_32(argv[2], &block_num) )
        {
            printf("block number is error.\r\n");
            return 0;
        }
        if(block_num <= 0)
        {
            printf("block number is error.\r\n");
            return 0;
        }
    }
    else
    {
        printf("the number of parameters are too many.\r\n");
        return 0;
    }
    
    if(bForce == 1)
    {
        nand_drv_block_erase_force(Nand_fd, block_num);
    }
    else
    {
        nand_drv_block_erase(Nand_fd, block_num);
    }
    
    return 0;
}

int32_t Function_mount(int32_t argc, char * argv[])
{
	int result;
	
	result = yaffs_mount(MOUNT_POINT);
	if(result != 0)
	{
	    printf("Mount \"%s\" failed!\r\n", MOUNT_POINT);
		return -1;
	}
	else
	{
	    printf("Mount \"%s\" successfully.\r\n", MOUNT_POINT);
	}
	
	return 0;
}

int32_t Function_unmount(int32_t argc, char * argv[])
{
	int result;
	
	result = yaffs_unmount(MOUNT_POINT);
	if(result != 0)
	{
	    printf("Unmount \"%s\" failed!\r\n", MOUNT_POINT);
		return -1;
	}
	else
	{
	    printf("Unmount \"%s\" successfully.\r\n", MOUNT_POINT);
	}
	
	return 0;
}

int32_t Function_get_free_space(int32_t argc, char * argv[])
{
	int result;
	
	result = yaffs_freespace(MOUNT_POINT);
	if(result == -1)
	{
	    printf("Get free space failed!\r\n");
	}
	else
	{
	    printf("Free space is %dB[%dKB][%dMB].\r\n", result, result/1024, result/(1024*1024));
	}
	
	return 0;
}

int32_t Function_make_directory(int32_t argc, char * argv[])
{
	int result;
	
	if(argc < 2)
	{
		printf("please input the directory name.\r\n");
		return 0;
	}
	
	char * dir_name = argv[1];
	
	result = yaffs_mkdir(dir_name, S_IREAD| S_IWRITE);
	if(result != 0)
	{
	    printf("Make directory \"%s\" failed!\r\n", dir_name);
		return 0;
	}
	else
	{
	    printf("Make directory \"%s\" successfully.\r\n", dir_name);
	}
	
	return 0;
}

int32_t Function_delete_directory(int32_t argc, char * argv[])
{
	int result;
	
	if(argc < 2)
	{
		printf("please input the directory name.\r\n");
		return 0;
	}
	
	char * dir_name = argv[1];
	
	result = yaffs_rmdir(dir_name);
	if(result != 0)
	{
	    printf("Delete directory \"%s\" failed!\r\n", dir_name);
		return 0;
	}
	else
	{
	    printf("Delete directory \"%s\" successfully.\r\n", dir_name);
	}
	
	return 0;
}

int32_t Function_make_file(int32_t argc, char * argv[])
{
	if(argc < 3)
	{
		printf("please input the file name or file size.\r\n");
		return 0;
	}
	
	char * filename = argv[1];
	int32_t filesize = 0;
	if( !Shell_parse_int_32(argv[2], &filesize) )
	{
		printf("file size is error!\r\n");
		return 0;
	}
	if(filesize <= 0)
	{
		printf("file size should be greater than 0.\r\n");
		return 0;
	}
    
    create_file_with_size(filename, filesize);
/*	
	fHandle = yaffs_open(filename, O_RDWR | O_CREAT | O_TRUNC, S_IREAD | S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open \"%s\" failed!\r\n", filename);
		return 0;
	}
	
	int loopCount, leftBytes;
	loopCount = filesize / MAX_ALLOC_BUFFER_LENGTH;
	leftBytes = filesize % MAX_ALLOC_BUFFER_LENGTH;
	
	wr_buf = (unsigned char *)kmalloc(MAX_ALLOC_BUFFER_LENGTH, 0);
	if(!wr_buf)
	{
		printf("malloc wr_buf failed!\r\n");
		goto RET;
	}
	for(i=0; i<MAX_ALLOC_BUFFER_LENGTH; i++)
	{
		wr_buf[i] = (i % 256);
	}
	
	for(i=0; i<loopCount; i++)
	{
		result = yaffs_write(fHandle, wr_buf, MAX_ALLOC_BUFFER_LENGTH);
		if(result == -1)
		{
			printf("[Loop:%d]Write %s failed!\n", i, filename);
			goto RET;
		}
		else
		{
			if(result < MAX_ALLOC_BUFFER_LENGTH)
			{
				printf("[Loop:%d]Should write %d, Actually written %d.\n", i, MAX_ALLOC_BUFFER_LENGTH, result);
			}
		}
	}
	if(leftBytes != 0)
	{
		result = yaffs_write(fHandle, wr_buf, leftBytes);
		if(result == -1)
		{
			printf("[Last]Write %s failed!\n", filename);
			goto RET;
		}
		else
		{
			if(result < leftBytes)
			{
				printf("[Last]Should write %d, Actually written %d.\n", leftBytes, result);
			}
		}
	}
	printf("Write \"%s\" successfully.\n", filename);
	
RET:
	kfree(wr_buf);
	result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("Close \"%s\" failed!\r\n", filename);
	}
	else
	{
	    printf("Close \"%s\" successfully.\r\n", filename);
	}
*/	
	return 0;
}

int32_t Function_read_file(int32_t argc, char * argv[])
{
	int result, i, k;
	int fHandle;
	unsigned char *rd_buf = NULL;
	int loopCount, leftBytes, filesize;
	
	if(argc < 2)
	{
		printf("please input the file name.\r\n");
		return 0;
	}
	
	char * filename = argv[1];
	
	fHandle = yaffs_open(filename, O_RDWR, S_IREAD | S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open \"%s\" failed!\r\n", filename);
		return 0;
	}
	
	struct yaffs_stat file_st;
	result = yaffs_lstat(filename, &file_st);
	if(result == -1)
	{
		printf("Get the state of \"%s\" failed!\r\n", filename);
		goto RET;
	}
	filesize = file_st.st_size;
	loopCount = filesize / MAX_ALLOC_BUFFER_LENGTH;
	leftBytes = filesize % MAX_ALLOC_BUFFER_LENGTH;
	
	printf("The size of \"%s\" is %d.\r\n", filename, filesize);
	
	rd_buf = (unsigned char *)kmalloc(MAX_ALLOC_BUFFER_LENGTH, 0);
	if(!rd_buf)
	{
		printf("malloc rd_buf failed!\r\n");
		goto RET;
	}
	memset(rd_buf, 0, MAX_ALLOC_BUFFER_LENGTH);
	
	for(i=0; i<loopCount; i++)
	{
		result = yaffs_read(fHandle, rd_buf, MAX_ALLOC_BUFFER_LENGTH);
		if(result == -1)
		{
			printf("[Loop:%d]Read \"%s\" failed!\r\n", i, filename);
			goto RET;
		}
		else
		{
			if(result < MAX_ALLOC_BUFFER_LENGTH)
			{
			    printf("[Loop:%d]Should read %d, Actually read %d.\r\n", i, MAX_ALLOC_BUFFER_LENGTH, result);
			}
			for(k=0; k<result; k++)
			{
				if(rd_buf[k] != (k % 256))
				{
				    printf("[Loop:%d]file data verified failed, should be %d, Actually %d.\r\n", i, k, rd_buf[k]);
					goto RET;
				}
			}
		}
	}
	if(leftBytes != 0)
	{
		result = yaffs_read(fHandle, rd_buf, leftBytes);
		if(result == -1)
		{
			printf("[Last]Read \"%s\" failed!\r\n", filename);
			goto RET;
		}
		else
		{
			if(result < leftBytes)
			{
			    printf("[Last]Should read %d, Actually read %d.\r\n", MAX_ALLOC_BUFFER_LENGTH, result);
			}
			for(k=0; k<result; k++)
			{
				if(rd_buf[k] != (k % 256))
				{
				    printf("[Last]file data verified failed, should be %d, Actually %d.\r\n", k, rd_buf[k]);
					goto RET;
				}
			}
		}
	}
    
    printf("read-verify the file which is made by \"mkfile\" command is successfully.\r\n");
	
RET:
	kfree(rd_buf);
	result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("Close \"%s\" failed!\r\n", filename);
	}
	else
	{
	    printf("Close \"%s\" successfully.\r\n", filename);
	}
	
	return 0;
}

int32_t Function_delete_file(int32_t argc, char * argv[])
{
    int result;
    int fHandle;
    
    if(argc < 2)
	{
		printf("please input the file name.\r\n");
		return 0;
	}
	
	char * filename = argv[1];
    
    fHandle = yaffs_open(filename, O_RDWR, S_IREAD | S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open \"%s\" failed!\r\n", filename);
		return 0;
	}
    
    result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("Close \"%s\" failed!\r\n", filename);
	}
    
    result = yaffs_unlink(filename);
    if(result != 0)
	{
		printf("Delete \"%s\" failed!\r\n", filename);
	}
    else
    {
        printf("Delete \"%s\" successfully.\r\n", filename);
    }
    
    return 0;
}

int32_t Function_make_files(int32_t argc, char * argv[])
{
    if(argc < 3)
	{
		printf("please input the file size or file numbers.\r\n");
		return 0;
	}
	
	int32_t filesize = 0;
	if( !Shell_parse_int_32(argv[1], &filesize) )
	{
		printf("file size is error!\r\n");
		return 0;
	}
	if(filesize <= 0)
	{
		printf("file size should be greater than 0.\r\n");
		return 0;
	}
    
    int32_t filenums = 0;
    if( !Shell_parse_int_32(argv[2], &filenums) )
	{
		printf("file numbers is error!\r\n");
		return 0;
	}
	if(filenums <= 0)
	{
		printf("file numbers should be greater than 0.\r\n");
		return 0;
	}
    
    char name_buf[128] = { 0 }; 
    int i = filenums;
    for(i=0; i<filenums; i++)
    {
        sprintf(name_buf, "/nand/file%d.dat", i);
        if(create_file_with_size(name_buf, filesize) != 0)
        {
            break;
        }
    }
    
    return 0;
}

int32_t Function_dump_directory(int32_t argc, char * argv[])
{
    if(argc < 2)
	{
		printf("please input the directory name.\r\n");
		return 0;
	}
	
	char * dir_name = argv[1];
    
    yaffs_DIR *d;
	struct yaffs_dirent *de;
	struct yaffs_stat s;
	char str[100];
	
	d = yaffs_opendir(dir_name);
	if(!d)
	{
	    printf("Open directory %s failed!\r\n", dir_name);
		return 0;
	}
	
	while( (de = yaffs_readdir(d)) != NULL )
	{
	    sprintf(str,"%s/%s",dir_name, de->d_name);
		yaffs_lstat(str, &s);
		printf("%s is ", str);
		switch(s.st_mode & S_IFMT)
		{
		case S_IFREG:
		    printf("data file, ");
		    break;
		case S_IFDIR:
		    printf("directory, ");
		    break;
		case S_IFLNK:
		    printf("symlink --> ");
			if(yaffs_readlink(str, str, 100) < 0)
			    printf("no alias, ");
			else
			    printf("\"%s\", ", str);
		    break;
		default:
		    printf("unkown type, ");
		    break;
		}
		printf("size is %d.\r\n", s.st_size);
	}
	
	yaffs_closedir(d);
    
    return 0;
}

int32_t Function_max_data_in_a_file(int32_t argc, char * argv[])
{
	int result;
	unsigned char byteToWrite = 0xA5;
	int fHandle;
	int writtenBytes, actualBytes;
	
	fHandle = yaffs_open("/nand/maxdata.dat", O_CREAT|O_TRUNC|O_RDWR, S_IREAD|S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open \"/nand/max_data.dat\" failed!\r\n");
		return 0;
	}
	
	printf("Writing data to a single file as much as possible...\r\n");

	result = yaffs_lseek(fHandle, 0, SEEK_SET);
	if(result == -1)
	{
		printf("Seek to file head failed!\r\n");
		return 0;
	}
	actualBytes = 0;
	while(1)
	{
		writtenBytes = yaffs_write(fHandle, &byteToWrite, sizeof(unsigned char));
		if(writtenBytes != sizeof(unsigned char))
		{
			printf("%d writes, should write 1, flash might be full!\r\n", writtenBytes);
			break;
		}
		actualBytes += writtenBytes;
	}

	printf("the max size of a single file is %d\r\n", actualBytes);
	
	result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("close \"/nand/max_data.dat\" failed!\r\n");
		return 0;
	}

	//Verify the file content
	fHandle = yaffs_open("/nand/maxdata.dat", O_CREAT|O_TRUNC|O_RDWR, S_IREAD|S_IWRITE);
	if(fHandle == -1)
	{
		printf("Open \"/nand/max_data.dat\" failed!\r\n");
		return 0;
	}
	
	unsigned char readByte = 0;
	while(actualBytes > 0)
	{
		readByte = 0;
		result = yaffs_read(fHandle, &readByte, sizeof(unsigned char));
		if(result == -1)
		{
			printf("read \"/nand/max_data.dat\" failed!\r\n");
			break;
		}
		else
		{
			if(readByte != byteToWrite)
			{
				printf("[%d]Verify failed, read 0x%X, but should 0x%X.\r\n", result, readByte, byteToWrite);
				break;
			}
			actualBytes--;
		}
	}

	result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("close \"/nand/max_data.dat\" failed!\r\n");
	}
	
	//delete
	result = yaffs_unlink("/nand/max_data.dat");
	if(result != 0)
	{
		printf("Delete \"/nand/max_data.dat\" failed!\r\n");
	}
	
	return 0;
}

int32_t Function_max_files_with_size(int32_t argc, char * argv[])
{
    int32_t filesize = 0;
    int max_files = 0;
    
    if(argc < 2)
	{
		printf("please input the file size.\r\n");
		return 0;
	}
	
	if( !Shell_parse_int_32(argv[1], &filesize) )
	{
		printf("file size is error!\r\n");
		return 0;
	}
	if(filesize <= 0)
	{
		printf("file size should be greater than 0.\r\n");
		return 0;
	}
    
    max_files = create_max_nums_files(filesize);
    printf("The maximum number of file[%dB] is %d.\r\n", filesize, max_files);
    
    return 0;
}

int32_t Function_1kb_files_test(int32_t argc, char * argv[])
{
    int max_files = 0;
    int i = 0;
    char name_buf[128] = { 0 };
	int leftSpace;
    
    printf("Filling FS with 1K bytes files:\r\n");
    max_files = create_max_nums_files(1024);
    printf("Max 1K byte files: %d\r\n", max_files);
    
    leftSpace = yaffs_freespace(MOUNT_POINT);
    printf("After fill maximum number of 1KB files, the left space is %dB.\r\n", leftSpace);
    
    printf("Delete half of these files:\r\n");
    for (i = 0; i <= max_files / 2; ++i) 
	{
		memset(name_buf, 0, 128);
        sprintf(name_buf, "/nand/file%d.dat", i);
        if(yaffs_unlink(name_buf) != 0) 
		{
            printf("delete %s failed!\r\n", name_buf);
            return 0;
        }
    }
    
    leftSpace = yaffs_freespace(MOUNT_POINT);
	printf("After deleting half of all 1KB files, the left space is %dB.\r\n", leftSpace);
    
    return 0;
}

int32_t Function_one_1kb_file_test(int32_t argc, char * argv[])
{
    unsigned char tmp_buf[128] = { 0 };
    int ret;
	int i = 0;
    
    // Write a 1k file
    printf("Create an 1K file.\r\n");
    ret = create_file_with_size("/nand/file_1k.dat", 1024);
    if (ret != 0) 
	{
        printf("Create 1K bytes file failed!\r\n");
		return 0;
    }
    
    printf("Append 1K bytes content.\r\n");
    ret = append_file_with_size("/nand/file_1k.dat", 1024);
	if (ret != 0) 
	{
        printf("Append 1K bytes to the file failed!\r\n");
		return 0;
    }
    
    printf("Check contents at offset 0:\r\n");
    ret = verify_file_with_size("/nand/file_1k.dat", 0, 1024);
	if(ret != 0)
	{
		printf("The first 1024 bytes verified failed!\r\n");
        return 0;
	}
	printf("The first 1024 bytes verified OK.\r\n");
    
    printf("Check contents at offset 1024:\n");
    ret = verify_file_with_size("/nand/file_1k.dat", 1024, 1024);
    if(ret != 0)
	{
		printf("The second 1024 bytes verified failed!\r\n");
        return 0;
	}
	printf("The second 1024 bytes verified OK.\r\n");
    
    printf("Modify contents at offset 1024:\n");
    memset(tmp_buf, 0xfc, 128);
    ret = write_data_to_file("/nand/file_1k.dat", 1024, tmp_buf, 128);
	if(ret != 0)
	{
		printf("Modify the content from offset %d failed!\r\n", 1024);
		return 0;
	}
    
    printf("Check contents at offset 1024 after modified:\n");
	memset(tmp_buf, 0, 128);
    ret = read_data_from_file("/nand/file_1k.dat", 1024, tmp_buf, 128);
	if(ret != 0)
	{
		printf("Read the content from offset %d failed!\r\n", 1024);
		return 0;
	}
	for(i=0; i<128; i++)
	{
		if(tmp_buf[i] != 0xfc)
		{
			printf("[Loop:%d]Verify the content after modified is failed!\r\n", i);
			break;
		}
	}
    printf("The contents at offset 1024 after modified verified OK.\r\n");
    
    return 0;
}

int32_t Function_one_file_multi_times_perf(int32_t argc, char * argv[])
{
    int file_size;
    int times;
    
    TIME_STRUCT time_start, time_end, diff_time;
	uint32_t time_write = 0, time_read = 0, time_delete = 0;
	int i = 0, j = 0;
	int result;
	int fHandle;
	unsigned char *wr_buf = NULL;
	uint32_t buf_len;
    int loopCount, leftBytes;
    
    if(argc < 3)
	{
		printf("please input the file size or times.\r\n");
		return 0;
	}
	
	if( !Shell_parse_int_32(argv[1], &file_size) )
	{
		printf("file size is error!\r\n");
		return 0;
	}
	if(file_size <= 0)
	{
		printf("file size should be greater than 0.\r\n");
		return 0;
	}
    
    if( !Shell_parse_int_32(argv[2], &times) )
    {
		printf("The times is error!\r\n");
		return 0;
	}
    if(times <= 0)
	{
		printf("The times should be greater than 0.\r\n");
		return 0;
	}
    
    //one file, multi times, average write, read & delete time
    fHandle = yaffs_open("/nand/perf1.dat", O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
    if(fHandle == -1)
	{
		printf("Open \"/nand/perf1.dat\" failed!\r\n");
		return 0;
	}
    
    if(file_size < MAX_ALLOC_BUFFER_LENGTH)
	{
		buf_len = file_size;
	}
	else
	{
		buf_len = MAX_ALLOC_BUFFER_LENGTH;
	}
    wr_buf = (unsigned char *)kmalloc(buf_len, 0);
	if(!wr_buf)
	{
		printf("malloc wr_buf failed!\r\n");
		goto RET;
	}
	for(i=0; i<buf_len; i++)
	{
		wr_buf[i] = (i % 256);
	}
    
    loopCount = file_size / MAX_ALLOC_BUFFER_LENGTH;
	leftBytes = file_size % MAX_ALLOC_BUFFER_LENGTH;
    
    _time_get(&time_start);
    for(j=0; j<times; j++)
    {
        yaffs_lseek(fHandle, 0, SEEK_SET);
        for(i=0; i<loopCount; i++)
        {
            result = yaffs_write(fHandle, wr_buf, MAX_ALLOC_BUFFER_LENGTH);
            if(result == -1)
            {
                printf("[Loop:%d]Write \"/nand/perf1.dat\" failed!\n", i);
                goto RET;
            }
           // else
           // {
           //     if(result < MAX_ALLOC_BUFFER_LENGTH)
           //     {
           //         printf("[Loop:%d]Should write %d, Actually written %d.\n", i, MAX_ALLOC_BUFFER_LENGTH, result);
           //     }
           // }
        }
        if(leftBytes != 0)
        {
            result = yaffs_write(fHandle, wr_buf, leftBytes);
            if(result == -1)
            {
                printf("[Last]Write \"/nand/perf1.dat\" failed!\n");
                goto RET;
            }
           // else
           // {
           //     if(result < leftBytes)
           //     {
           //         printf("[Last]Should write %d, Actually written %d.\n", leftBytes, result);
           //     }
           // }
        }
    }
    _time_get(&time_end);
    _time_diff(&time_start, &time_end, &diff_time);
	time_write += diff_time.MILLISECONDS + diff_time.SECONDS * 1000;
    
    _time_get(&time_start);
    for(j=0; j<times; j++)
    {
        yaffs_lseek(fHandle, 0, SEEK_SET);
        for(i=0; i<loopCount; i++)
        {
            result = yaffs_read(fHandle, wr_buf, MAX_ALLOC_BUFFER_LENGTH);
            if(result == -1)
            {
                printf("[Loop:%d]Read \"/nand/perf1.dat\" failed!\n", i);
                goto RET;
            }
        }
        if(leftBytes != 0)
        {
            result = yaffs_read(fHandle, wr_buf, leftBytes);
            if(result == -1)
            {
                printf("[Last]Read \"/nand/perf1.dat\" failed!\n");
                goto RET;
            }
        }
    }
    _time_get(&time_end);
    _time_diff(&time_start, &time_end, &diff_time);
	time_read += diff_time.MILLISECONDS + diff_time.SECONDS * 1000;
    
    _time_get(&time_start);
	yaffs_close(fHandle);
	yaffs_unlink("/nand/perf1.dat");
	_time_get(&time_end);
	_time_diff(&time_start, &time_end, &diff_time);
	time_delete += diff_time.MILLISECONDS + diff_time.SECONDS * 1000;
    
    printf("One file(%dB),Operate times(%d), Time Created: %d ms, Time Read: %d ms, Time Delete: %d ms\r\n",
           file_size, times, time_write, time_read, time_delete);
	
RET:
	kfree(wr_buf);
/*	result = yaffs_close(fHandle);
	if(result != 0)
	{
		printf("Close \"/nand/perf1.dat\" failed!\r\n");
	}
	else
	{
	    printf("Close \"/nand/perf1.dat\" successfully.\r\n");
	}
*/    
    return 0;
}

int32_t Function_multi_files_one_time_perf(int32_t argc, char * argv[])
{
    int file_size;
    int file_nums;
    TIME_STRUCT time_start, time_end, diff_time;
	uint32_t time_write = 0, time_read = 0, time_delete = 0;
	int i = 0, j = 0;
    int result;
	int fHandle;
	unsigned char *wr_buf = NULL;
	uint32_t buf_len;
    int loopCount, leftBytes;
    char name_buf[128] = { 0 };
    
    if(argc < 3)
	{
		printf("please input the file size or file numbers.\r\n");
		return 0;
	}
	
	if( !Shell_parse_int_32(argv[1], &file_size) )
	{
		printf("file size is error!\r\n");
		return 0;
	}
	if(file_size <= 0)
	{
		printf("file size should be greater than 0.\r\n");
		return 0;
	}
    
    if( !Shell_parse_int_32(argv[2], &file_nums) )
    {
		printf("The file number is error!\r\n");
		return 0;
	}
    if(file_nums <= 0)
	{
		printf("The file number should be greater than 0.\r\n");
		return 0;
	}
    
    //multi files, one time, average write, read & delete time
    if(file_size < MAX_ALLOC_BUFFER_LENGTH)
	{
		buf_len = file_size;
	}
	else
	{
		buf_len = MAX_ALLOC_BUFFER_LENGTH;
	}
    wr_buf = (unsigned char *)kmalloc(buf_len, 0);
	if(!wr_buf)
	{
		printf("malloc wr_buf failed!\r\n");
		goto RET;
	}
	for(i=0; i<buf_len; i++)
	{
		wr_buf[i] = (i % 256);
	}
    
    loopCount = file_size / MAX_ALLOC_BUFFER_LENGTH;
	leftBytes = file_size % MAX_ALLOC_BUFFER_LENGTH;
    
    for(j=0; j<file_nums; j++)
    {
        sprintf(name_buf, "/nand/perf2_%d.dat", j);
        fHandle = yaffs_open(name_buf, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
        if(fHandle == -1)
		{
			printf("Open \"%s\" failed!\r\n", name_buf);
			kfree(wr_buf);
			return 0;
		}
        _time_get(&time_start);
        for(i=0; i<loopCount; i++)
        {
            result = yaffs_write(fHandle, wr_buf, MAX_ALLOC_BUFFER_LENGTH);
            if(result == -1)
            {
                printf("[Loop:%d]Write \"/nand/perf1.dat\" failed!\n", i);
                goto RET;
            }
           // else
           // {
           //     if(result < MAX_ALLOC_BUFFER_LENGTH)
           //     {
           //         printf("[Loop:%d]Should write %d, Actually written %d.\n", i, MAX_ALLOC_BUFFER_LENGTH, result);
           //     }
           // }
        }
        if(leftBytes != 0)
        {
            result = yaffs_write(fHandle, wr_buf, leftBytes);
            if(result == -1)
            {
                printf("[Last]Write \"/nand/perf1.dat\" failed!\n");
                goto RET;
            }
           // else
           // {
           //     if(result < leftBytes)
           //     {
           //         printf("[Last]Should write %d, Actually written %d.\n", leftBytes, result);
           //     }
           // }
        }
        _time_get(&time_end);
        _time_diff(&time_start, &time_end, &diff_time);
		time_write += diff_time.MILLISECONDS + diff_time.SECONDS * 1000;
        yaffs_close(fHandle);
    }
    
    for(j=0; j<file_nums; j++)
    {
        sprintf(name_buf, "/nand/perf2_%d.dat", j);
        fHandle = yaffs_open(name_buf, O_CREAT|O_RDWR|O_TRUNC, S_IREAD|S_IWRITE);
        if(fHandle == -1)
		{
			printf("Open \"%s\" failed!\r\n", name_buf);
			kfree(wr_buf);
			return 0;
		}
        _time_get(&time_start);
        for(i=0; i<loopCount; i++)
        {
            result = yaffs_read(fHandle, wr_buf, MAX_ALLOC_BUFFER_LENGTH);
            if(result == -1)
            {
                printf("[Loop:%d]Read \"/nand/perf1.dat\" failed!\n", i);
                goto RET;
            }
        }
        if(leftBytes != 0)
        {
            result = yaffs_read(fHandle, wr_buf, leftBytes);
            if(result == -1)
            {
                printf("[Last]Read \"/nand/perf1.dat\" failed!\n");
                goto RET;
            }
        }
        _time_get(&time_end);
        _time_diff(&time_start, &time_end, &diff_time);
		time_read += diff_time.MILLISECONDS + diff_time.SECONDS * 1000;
        yaffs_close(fHandle);
    }
    
    for(j=0; j<file_nums; j++)
	{
		sprintf(name_buf, "/nand/perf2_%d.dat", j);
		_time_get(&time_start);
		yaffs_unlink(name_buf);
		_time_get(&time_end);
		_time_diff(&time_start, &time_end, &diff_time);
		time_delete += diff_time.MILLISECONDS + diff_time.SECONDS * 1000;
	}
    
    printf("Multi file(%d, %dB),Operate one time, Time Created: %d ms, Time Read: %d ms, Time Delete: %d ms\r\n",
           file_nums, file_size, time_write, time_read, time_delete);
    
RET:
    kfree(wr_buf);
    
    return 0;
}

int32_t Function_command_description(int32_t argc, char * argv[])
{
    int i = 0;
	printf("\r\n");
	printf("****************************************\r\n");
	printf("* Command Description\r\n");
	printf("****************************************\r\n");

	for(i=0; NULL!=(Shell_commands[i].COMMAND); i++)
	{
		printf("%s: --%s\r\n", Shell_commands[i].COMMAND, Command_Description[i]);
	}

	return 0;
}

int init_yaffs()
{
    int result;
	
	result = yaffs_start_up();
	if(result != YAFFS_OK)
	{
	    printf("Start yaffs2 failed!\r\n");
		return -1;
	}
	else
	{
	    printf("Start yaffs2 successfully, the root is \"%s\".\r\n", MOUNT_POINT);
	}
    
/*    result = yaffs_mount(MOUNT_POINT);
	if(result != 0)
	{
	    printf("Mount \"%s\" failed!\r\n", MOUNT_POINT);
		return -1;
	}
	else
	{
	    printf("Mount \"%s\" successfully.\r\n", MOUNT_POINT);
	}
*/	
	return 0;
}

void Multi_Test_Task(uint32_t initial_data)
{
    printf("\r\n\r\n***************************************************\r\n");
    printf("* Yaffs2 filesystem test\r\n");
    printf("*******************************************************\r\n\r\n");
    
    //ext_sram_pool = _mem_create_pool(BSP_EXTERNAL_DDR2_RAM_BASE, (_mem_size)BSP_EXTERNAL_DDR2_RAM_SIZE);
	
	int result;
	
	result = init_yaffs();
	if(result != 0)
	{
		_task_block();
	}
	
	for(;;)  
    {
       Shell(Shell_commands, NULL);
       printf("Shell exited, restarting...\r\n");
    }
}

