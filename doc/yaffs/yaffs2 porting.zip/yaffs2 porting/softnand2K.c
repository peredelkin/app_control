/**HEADER***********************************************************************
*
* Copyright (c) 2014 Freescale Semiconductor;
* All Rights Reserved
*
********************************************************************************
*
* THIS SOFTWARE IS PROVIDED BY FREESCALE "AS IS" AND ANY EXPRESSED OR
* IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
* OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
* IN NO EVENT SHALL FREESCALE OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
* INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
* SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
* HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
* STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
* IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
* THE POSSIBILITY OF SUCH DAMAGE.
*
********************************************************************************
*
* $FileName: softnand2k.c$
* $Version : 1.0.0$
* $Date    : Jun-6-2014$
* $Author  : Lu Lin (lin.lu@freescale.com)
*
* Comments:
*
*   The file contains functions to access NAND Flash through FlexBus.
*
*END***************************************************************************/

#include "mqx.h"
#include "bsp.h"
#include "nandflash.h"
#include "nandflashprv.h"
#include "nfc.h"

#define NAND_DEBUG	0
#define NANDFLASH_ID	0x9551D3EC

extern void nand_ecc(uint_8 *buf, uint_8 *ecc);
extern uint_32 nand_ecc_correct(uint_8 *buf, uint_8 *read_ecc, uint_8 *calc_ecc);

static volatile uint_8 *CmdPort = (uint_8*) BSP_NAND_CLE_PORT_ADDR;
static volatile uint_8 *AddrPort = (uint_8*) BSP_NAND_ALE_PORT_ADDR;
static volatile uint_8 *DataPort = (uint_8*) BSP_DEFAULT_BASE_OF_NAND;

static void Nand_EnableCS(uint_32 enable)
{ 
    if(enable)
	{
        GPIO_PCOR_REG(PTA_BASE_PTR) |= (0x1 << 7);
	}
    else
	{
        GPIO_PSOR_REG(PTA_BASE_PTR) |= (0x1 << 7);
	}
}

/* return bit0=0 successful, bit0=1 failed */
/* bit6=0 busy, bit6=1 ready */
/* bit7=0 write protect, bit7=1 not protect */
static uint_8 Nand_ReadStatus(void)
{
    *CmdPort = 0x70;
	
    return *DataPort;
}

static uint_32 Nand_WaitIOReady(void)
{
    int i;
    
    for(i=0;i<100;i++);
    
    for(i=0;i<MAX_WAIT_COMMAND;i++)
    {
    	if(GPIO_PDIR_REG(PTA_BASE_PTR) & (0x1<<6))
		{
      	    return NANDFLASHERR_NO_ERROR;
		}
    }
    
    printf("Nand_WaitIOReady() is timeout\n");
    
    return NANDFLASHERR_TIMEOUT;
}

static uint_32 Nand_WaitStatusReady(void)
{
    uint_8 status;
    int i;

	for(i=0;i<MAX_WAIT_COMMAND;i++)
	{
        status = Nand_ReadStatus();
        if(status & (0x1<<6))
		{
            return NANDFLASHERR_NO_ERROR;
		}
    }

    printf("Nand_WaitStatusReady() is timeout\n");
	
    return NANDFLASHERR_TIMEOUT;
}


/*FUNCTION*---------------------------------------------------------------------
*
* Function Name    : nfc_init
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_IMPROPER_ECC_SIZE
*                    NANDFLASHERR_INFO_STRUC_MISSING
*                    MQX_OUT_OF_MEMORY
* Comments         :
*    This function initializes the driver.
*
*END*-------------------------------------------------------------------------*/

uint_32 nfc_init
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr
   )
{ /* Body */

	uint_32 nand_id;
	NANDFLASH_INFO_STRUCT_PTR nand_info_ptr;

	if (((*nandflash_ptr->IOCTL)(nandflash_ptr, NANDFLASH_IOCTL_GET_ID, &nand_id)) != NANDFLASHERR_NO_ERROR)
	{
		return ((uint_32)NANDFLASHERR_INFO_STRUC_MISSING);
	}
		
	if(nand_id != NANDFLASH_ID)
	{
		printf("nfc_init: nand id(0x%x) is not correct\n",nand_id);
		return ((uint_32)NANDFLASHERR_INFO_STRUC_MISSING);
	}
 	/* Create NANDFLASH_INFO_STRUCT based on NAND ID read from the NAND Flash,
    if not defined before manually */
	if((nandflash_ptr->NANDFLASH_INFO_PTR) == NULL)
	{
		nand_info_ptr = (NANDFLASH_INFO_STRUCT_PTR)_mem_alloc_system_zero(
                     (_mem_size)sizeof(NANDFLASH_INFO_STRUCT));

#if MQX_CHECK_MEMORY_ALLOCATION_ERRORS
		if(nand_info_ptr == NULL)
		{
			return((uint_32)MQX_OUT_OF_MEMORY);
		} /* Endif */
#endif

		nand_info_ptr->PHY_PAGE_SIZE = 2048;
		nand_info_ptr->SPARE_AREA_SIZE = 64;
		nand_info_ptr->BLOCK_SIZE = (64*2048);
		nand_info_ptr->NUM_BLOCKS = 4096;
		nand_info_ptr->WIDTH = 8;
		
		nandflash_ptr->NANDFLASH_INFO_PTR = nand_info_ptr;
		nandflash_ptr->NUM_VIRTUAL_PAGES  =	((nand_info_ptr->BLOCK_SIZE)/(nandflash_ptr->VIRTUAL_PAGE_SIZE))*(nand_info_ptr->NUM_BLOCKS);
		nandflash_ptr->PHY_PAGE_SIZE_TO_VIRTUAL_PAGE_SIZE_RATIO = (nand_info_ptr->PHY_PAGE_SIZE)/(nandflash_ptr->VIRTUAL_PAGE_SIZE);
  }

	return NANDFLASHERR_NO_ERROR;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_deinit
* Returned Value   :
* Comments         :
*    This function de-initializes the driver.
*
*END*----------------------------------------------------------------------*/
void nfc_deinit
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr
   )
{ /* Body */

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_erase_flash
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_ERASE_FAILED
* Comments         :
*    This function erases the whole NAND Flash using the NFC module.
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_erase_flash
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr
   )
{ /* Body */

	uint_32 count;

	for (count = 0; count < (nandflash_ptr->NANDFLASH_INFO_PTR->NUM_BLOCKS); count++)
	{
		if (NANDFLASHERR_NO_ERROR != nfc_erase_block(nandflash_ptr, count, FALSE))
        {
            printf("nfc_erase_flash, erase block[%d] failed\n",count);
            return NANDFLASHERR_ERASE_FAILED;
        }
	}
	
	return NANDFLASHERR_NO_ERROR;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_erase_block
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_ERASE_FAILED or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function erases the defined block of NAND Flash
*    using the NFC module.
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_erase_block
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr,

      /* [IN] the block to erase */
      uint_32                 block_number,

      /* [IN] TRUE = force block erase in case the block is marked as bad */
      boolean                 force_flag
   )
{ /* Body */
	uint_8 status;
	uint_32 count,result = NANDFLASHERR_TIMEOUT;
	//uint_32 blockaddr = ((nandflash_ptr->NANDFLASH_INFO_PTR->BLOCK_SIZE * block_number) >> 20);
	//uint_32 blockaddr = ( (nandflash_ptr->NANDFLASH_INFO_PTR->BLOCK_SIZE)/(nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE) * block_number );
    uint_32 blockaddr = ( 64 * block_number );
	
	/* Do not erase block if force_flag is zero and the block is marked as bad */
	if( (!force_flag) && (NANDFLASHERR_BLOCK_NOT_BAD != nfc_check_block(nandflash_ptr, block_number)) )
	{
        printf("nfc_erase_block: block[%d] is bad\n", block_number);
	    return NANDFLASHERR_ERASE_FAILED;
	}
	
	if (nandflash_ptr->WRITE_PROTECT) 
	{
	   (*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, FALSE);
	}/* Endif */
	
	Nand_EnableCS(1);

	*CmdPort = NANDFLASH_CMD_BLOCK_ERASE_CYCLE1;
	*AddrPort = ((blockaddr )& 0xff);
	*AddrPort = ((blockaddr >> 8) &0xff);
	*AddrPort = ((blockaddr >> 16) &0xff);
	*CmdPort = NANDFLASH_CMD_BLOCK_ERASE_CYCLE2;
    
//    if(NANDFLASHERR_TIMEOUT == Nand_WaitIOReady())
//	{
//		Nand_EnableCS(0);
//		return NANDFLASHERR_TIMEOUT;
//	}
	
	if (Nand_WaitStatusReady() == NANDFLASHERR_TIMEOUT)
	{
		Nand_EnableCS(0);
		result = NANDFLASHERR_TIMEOUT;
        printf("nfc_erase_block: block[%d] Nand_WaitStatusReady timeout\n", block_number);
		goto ret;
	}
	
	status = Nand_ReadStatus();
	Nand_EnableCS(0);
	if(status & 0x01)
	{
		printf("nfc_erase_block: erase block[%d] error\n",block_number);
		result = NANDFLASHERR_ERASE_FAILED;
	}
	else
	{
		result = NANDFLASHERR_NO_ERROR;
	}
		
ret:
	if (nandflash_ptr->WRITE_PROTECT) 
	{
		(*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, TRUE);
	}/* Endif */
	
	return(result);
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_read_page
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_ECC_FAILED or
*                    NANDFLASHERR_ECC_CORRECTED or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function reads one or several pages of NAND Flash
*    using the NFC module.
*
*END*----------------------------------------------------------------------*/

////////////////
// may not one full page
///////////////
uint_32 nfc_read_page
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr,

      /* [OUT} where to copy data to */
      uchar_ptr               to_ptr,

      /* [IN] the page to read */
      uint_32                 page_number,

      /* [IN] the amount of pages to read */
      uint_32                 page_count
   )
{ /* Body */
	uint_32 i,j,result;
	boolean ecc_corrected = FALSE;
	uint_32 pageaddr = page_number*nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;
	uint_8 read_ecc[3],calc_ecc[3];
#if NAND_DEBUG
	printf("nfc_read_page %d...\n",page_number);
#endif	
	for (i = page_number; i < (page_number + page_count); i++)
	{
		Nand_EnableCS(1);

		*CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE1;
        *AddrPort = 0;
        *AddrPort = 0;
		*AddrPort = (pageaddr & 0xff);
		*AddrPort = ((pageaddr >> 8) & 0xff);
		*AddrPort = ((pageaddr >> 16) & 0xff);
		//*AddrPort = ((pageaddr >> 24) & 0xff);
        *CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE2;

		if(NANDFLASHERR_TIMEOUT == Nand_WaitIOReady())
		{
			Nand_EnableCS(0);
			return NANDFLASHERR_TIMEOUT;
		}

		for(j=0;j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;j++)
   		*(to_ptr + j) = *DataPort;

/*		for(j=0;j<3;j++)
			read_ecc[j] = *DataPort;

		Nand_EnableCS(0);   

		//ECC calculation
		nand_ecc(to_ptr, calc_ecc);
		if(((read_ecc[0] ^ calc_ecc[0])!=0) ||
		   ((read_ecc[1] ^ calc_ecc[1])!=0) ||
		   ((read_ecc[2] ^ calc_ecc[2])!=0))
		{
			result = nand_ecc_correct(to_ptr, read_ecc, calc_ecc);
			if(result == NANDFLASHERR_ECC_FAILED)
			{
#if NAND_DEBUG				
				printf("nfc_read_page(): page%d ECC error\n",i);
#endif				
				return NANDFLASHERR_ECC_FAILED;
			}
			else if(result == NANDFLASHERR_ECC_CORRECTED)
			{
				ecc_corrected = TRUE;
				//printf("nfc_read_page(): page%d ECC is corrected\n",i);
			}
		}
*/		
		pageaddr += nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;
		to_ptr += nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;
    }

/*	if(ecc_corrected)
		return NANDFLASHERR_ECC_CORRECTED;
	else
		return NANDFLASHERR_NO_ERROR; */
    return NANDFLASHERR_NO_ERROR;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_read_one_full_page
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_ECC_FAILED or
*                    NANDFLASHERR_ECC_CORRECTED or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function reads one full page of NAND Flash(include OOB)
*
*END*----------------------------------------------------------------------*/
uint_32 nfc_read_one_full_page
	(
	   /* [IN] the NAND flash information */
	   IO_NANDFLASH_STRUCT_PTR nandflash_ptr,
	
	   /* [OUT} where to copy data to */
	   uchar_ptr			   data_to_ptr,

	   /* [OUT} where to copy spare area data to */
	   uchar_ptr 			  spare_to_ptr,
	
	   /* [IN] the page to read */
	   uint_32				   page_number
	)
{ /* Body */
	uint_32 i,j,result;
    uint_32 k;
	boolean ecc_corrected = FALSE;
	//uint_32 pageaddr = (page_number * nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE);
    uint_32 pageaddr = page_number;
	uint_8 read_ecc[3],calc_ecc[3];
    uint_8 tmpData = 0;

	Nand_EnableCS(1);

	*CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE1;
    *AddrPort = 0;
    *AddrPort = 0;
    *AddrPort = (pageaddr & 0xff);
    *AddrPort = ((pageaddr >> 8) & 0xff);
    *AddrPort = ((pageaddr >> 16) & 0xff);
    *CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE2;
	
	if(NANDFLASHERR_TIMEOUT == Nand_WaitIOReady())
	{
		Nand_EnableCS(0);
		return NANDFLASHERR_TIMEOUT;
	}
//    for(k=0; k<100000; k++);

    if(data_to_ptr != NULL)
    {
        for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE; j++)
        {
            *(data_to_ptr + j) = *DataPort;
        }
    }
    else
    {
        for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE; j++)
        {
            tmpData = *DataPort;
        }
    }

    if(spare_to_ptr != NULL)
    {
        for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->SPARE_AREA_SIZE; j++)
        {
            *(spare_to_ptr + j) = *DataPort;
        }
    }
    else
    {
        for(j=0; j<(nandflash_ptr->NANDFLASH_INFO_PTR->SPARE_AREA_SIZE); j++)
        {
            tmpData = *DataPort;
        }
    }

	Nand_EnableCS(0);

	return NANDFLASHERR_NO_ERROR;
	
/*	for(j=0;j<3;j++)
	{
		read_ecc[j] = *(spare_to_ptr + j + 8);
	}
	//ECC calculation
	nand_ecc(data_to_ptr, calc_ecc);
	if(((read_ecc[0] ^ calc_ecc[0])!=0) ||
	   ((read_ecc[1] ^ calc_ecc[1])!=0) ||
	   ((read_ecc[2] ^ calc_ecc[2])!=0))
	{
		result = nand_ecc_correct(data_to_ptr, read_ecc, calc_ecc);
		if(result == NANDFLASHERR_ECC_FAILED)
		{
#if NAND_DEBUG				
			printf("nfc_read_one_full_page(): page%d ECC error\n",i);
#endif				
			return NANDFLASHERR_ECC_FAILED;
		}
		else if(result == NANDFLASHERR_ECC_CORRECTED)
		{
			ecc_corrected = TRUE;
			//printf("nfc_read_page(): page%d ECC is corrected\n",i);
		}
	}
	if(ecc_corrected)
		return NANDFLASHERR_ECC_CORRECTED;
	else 
	    return NANDFLASHERR_NO_ERROR; */
} /* Endbody */




/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_write_page
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_WRITE_FAILED or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function writes one or several pages of NAND Flash
*    using the NFC module.
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_write_page
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr,

      /* [IN] where to copy data from */
      uchar_ptr               from_ptr,

      /* [IN] the first page to write */
      uint_32                 page_number,

      /* [IN] the amount of pages to write */
      uint_32                 page_count
   )
{ /* Body */
	uint_32 result = NANDFLASHERR_NO_ERROR;
	uint_32 i,j;
	uint_32 pageaddr = page_number*nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;
	uint_8 calc_ecc[3],status;

#if NAND_DEBUG
	printf("nfc_write_page %d...\n",page_number);
#endif

	if (nandflash_ptr->WRITE_PROTECT) {
		(*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, FALSE);
	}/* Endif */

	for (i = page_number; i < (page_number + page_count); i++)
	{
		//ECC Computing to fill spare byte
//		nand_ecc(from_ptr, calc_ecc);
   	
		Nand_EnableCS(1);

//   	*CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE1;
		
		*CmdPort = NANDFLASH_CMD_PAGE_PROGRAM_CYCLE1;
        *AddrPort = 0;
        *AddrPort = 0;
		*AddrPort = (pageaddr & 0xff);
		*AddrPort = ((pageaddr >> 8) & 0xff);
		*AddrPort = ((pageaddr >> 16) & 0xff);
		//*AddrPort = ((pageaddr >> 24) & 0xff);
		
		for(j=0;j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;j++)
			*DataPort = *(from_ptr+j);

		//for(j=0;j<3;j++)
   		//*DataPort = calc_ecc[j];
	
		*CmdPort = NANDFLASH_CMD_PAGE_PROGRAM_CYCLE2;

		if(Nand_WaitStatusReady() ==NANDFLASHERR_TIMEOUT )
		{
			result = NANDFLASHERR_TIMEOUT;
			Nand_EnableCS(0);
			goto ret;
		}
	
		status = Nand_ReadStatus();
		Nand_EnableCS(0);
		if(status & 0x1)
		{
#if NAND_DEBUG			
			printf("nfc_write_page() failed at page%d\n",i);
#endif			
			result = NANDFLASHERR_WRITE_FAILED;
			goto ret;
		}
	 
		from_ptr += nandflash_ptr->VIRTUAL_PAGE_SIZE;
		pageaddr += nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;
	}
	
ret:
   if (nandflash_ptr->WRITE_PROTECT) {
      (*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, TRUE);
   }/* Endif */
   
   return(result);

} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_write_one_full_page
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_WRITE_FAILED or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function writes one page of NAND Flash(include spare area)
*
*END*----------------------------------------------------------------------*/
uint_32 nfc_write_one_full_page
	(
	  /* [IN] the NAND flash information */
	  IO_NANDFLASH_STRUCT_PTR nandflash_ptr,
	
	  /* [IN] where to copy data from */
	  uchar_ptr 			  data_from_ptr,

	  /* [IN] where to copy spare from */
	  uchar_ptr 			  spare_from_ptr,

	  /* [IN] the first page to write */
	  uint_32				  page_number
	)
{ /* Body */
	uint_32 result = NANDFLASHERR_NO_ERROR;
	uint_32 i,j;
	//uint_32 pageaddr = page_number*nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE;
    uint_32 pageaddr = page_number;
	uint_8 calc_ecc[3],status;
	
	if (nandflash_ptr->WRITE_PROTECT) 
	{
        (*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, FALSE);
	}/* Endif */

/*	//ECC Computing to fill spare byte
	nand_ecc(data_from_ptr, calc_ecc);
	for(j=0; j<3; j++)
	{
		spare_from_ptr[j+8] = calc_ecc[j];
	}
*/	
	Nand_EnableCS(1);
	*CmdPort = NANDFLASH_CMD_PAGE_PROGRAM_CYCLE1;
    *AddrPort = 0;
    *AddrPort = 0;
	*AddrPort = (pageaddr & 0xff);
	*AddrPort = ((pageaddr >> 8) & 0xff);
	*AddrPort = ((pageaddr >> 16) & 0xff);
	//*AddrPort = ((pageaddr >> 24) & 0xff);

	for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE; j++)
	{
		*DataPort = *(data_from_ptr+j);
	}
	for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->SPARE_AREA_SIZE; j++)
	{
		*DataPort = *(spare_from_ptr+j);
	}
	*CmdPort = NANDFLASH_CMD_PAGE_PROGRAM_CYCLE2;

	if(Nand_WaitStatusReady() ==NANDFLASHERR_TIMEOUT)
	{
		result = NANDFLASHERR_TIMEOUT;
        printf("nfc_write_one_full_page: Nand_WaitStatusReady timeout page[%d]\n",page_number);
		Nand_EnableCS(0);
		goto ret;
	}
	status = Nand_ReadStatus();
	Nand_EnableCS(0);
	if(status & 0x1)
	{
	    printf("nfc_write_one_full_page: write page[%d] failed\n",page_number);
		result = NANDFLASHERR_WRITE_FAILED;
		goto ret;
	}
ret:
   if (nandflash_ptr->WRITE_PROTECT) 
   {
	  (*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, TRUE);
   }/* Endif */
	   
   return(result);
}


/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_reset
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function resets the NAND Flash using the NFC module.
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_reset
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr
   )
{ /* Body */

   uint_32 result;

   //printf("nfc_reset ...\n");
   
   Nand_EnableCS(1);
   
   *CmdPort = NANDFLASH_CMD_RESET;

   result = Nand_WaitStatusReady();
		
   Nand_EnableCS(0);

   return result;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_check_block
* Returned Value   : NANDFLASHERR_BLOCK_NOT_BAD or
*                    NANDFLASHERR_BLOCK_BAD or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function checks if the defined NAND Flash block is bad or not
*    using the NFC module.
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_check_block
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr,

      /* [IN] block to check */
      uint_32                 block_number
   )
{ /* Body */
	uint_32 j, k;
	//uint_32 pageaddr = nandflash_ptr->NANDFLASH_INFO_PTR->BLOCK_SIZE * block_number;
    uint_32 pageaddr = (nandflash_ptr->NANDFLASH_INFO_PTR->BLOCK_SIZE/nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE) * block_number;
	uint_8 blockStatus;
	uint_8 tmpData;

	Nand_EnableCS(1);
	
	*CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE1;
    *AddrPort = 0;
    *AddrPort = 0;
	*AddrPort = (pageaddr & 0xff);
	*AddrPort = ((pageaddr >> 8) & 0xff);
	*AddrPort = ((pageaddr >> 16) & 0xff);
	//*AddrPort = ((pageaddr >> 24) & 0xff);
	*CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE2;
	
	if(NANDFLASHERR_TIMEOUT == Nand_WaitIOReady())
	{
		Nand_EnableCS(0);
		return NANDFLASHERR_TIMEOUT;
	}

	for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE; j++)
    {
        tmpData = *DataPort;
    }
	blockStatus = *DataPort;
	
	Nand_EnableCS(0); 
	
	if(blockStatus != 0xff)
    {
        printf("nfc_check_block: block[%d] is bad\n", block_number);
        return NANDFLASHERR_BLOCK_BAD;
    }
	else
	{
	    pageaddr += 1;
		Nand_EnableCS(1);
		*CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE1;
        *AddrPort = 0;
        *AddrPort = 0;
	    *AddrPort = (pageaddr & 0xff);
	    *AddrPort = ((pageaddr >> 8) & 0xff);
	    *AddrPort = ((pageaddr >> 16) & 0xff);
	    //*AddrPort = ((pageaddr >> 24) & 0xff);
	    *CmdPort = NANDFLASH_CMD_PAGE_READ_CYCLE2;
		
		if(NANDFLASHERR_TIMEOUT == Nand_WaitIOReady())
        {
		    Nand_EnableCS(0);
		    return NANDFLASHERR_TIMEOUT;
	    }
//        for(k=0; k<100000; k++);

		for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE; j++)
        {
            tmpData = *DataPort;
        }
	    blockStatus = *DataPort;
		
		Nand_EnableCS(0); 
		if(blockStatus != 0xff)
        {
            printf("nfc_check_block: block[%d] is bad\n", block_number);
            return NANDFLASHERR_BLOCK_BAD;
        }
	}
	
	return NANDFLASHERR_BLOCK_NOT_BAD;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_mark_block_as_bad
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_WRITE_FAILED or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function marks the defined NAND Flash block as bad
*    using the NFC module (writing 0x00 to the first spare area byte).
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_mark_block_as_bad
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr,

      /* [IN] block to mark as bad */
      uint_32                 block_number
   )
{ /* Body */
	uint_32 j,result,status;
	uint_32 pageaddr = (nandflash_ptr->NANDFLASH_INFO_PTR->BLOCK_SIZE/nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE) * block_number;
	uint_8 blockStatus;

	nfc_erase_block(nandflash_ptr, block_number, FALSE);

    if (nandflash_ptr->WRITE_PROTECT) 
    {
        (*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, FALSE);
    }/* Endif */

	blockStatus = 0;
	
	Nand_EnableCS(1);

	*CmdPort = NANDFLASH_CMD_PAGE_PROGRAM_CYCLE1;
    *AddrPort = 0;
    *AddrPort = 0;
	*AddrPort = (pageaddr & 0xff);
	*AddrPort = ((pageaddr >> 8) & 0xff);
	*AddrPort = ((pageaddr >> 16) & 0xff);
	//*AddrPort = ((pageaddr >> 24) & 0xff);
	
	for(j=0; j<nandflash_ptr->NANDFLASH_INFO_PTR->PHY_PAGE_SIZE; j++)
	{
		*DataPort = 0xFF;
	}
	*DataPort = blockStatus;
	*CmdPort = NANDFLASH_CMD_PAGE_PROGRAM_CYCLE2;
   
    if(Nand_WaitIOReady() == NANDFLASHERR_TIMEOUT)
    {
        printf("nfc_mark_block_as_bad() block%d Nand_WaitIOReady() timeout\n",block_number);
    	result = NANDFLASHERR_TIMEOUT;
		Nand_EnableCS(0);
		goto ret;
    }
   
 	status = Nand_ReadStatus();
	Nand_EnableCS(0);
	if(status & 0x1)
    {
        printf("nfc_mark_block_as_bad() block%d mark failed \n",block_number);
        result = NANDFLASHERR_WRITE_FAILED;
    }
	else
	{
		result = NANDFLASHERR_NO_ERROR;
	}
	
ret:
	if (nandflash_ptr->WRITE_PROTECT) 
	{
		(*nandflash_ptr->WRITE_PROTECT)(nandflash_ptr, TRUE);
	}/* Endif */

	return(result);
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_read_ID
* Returned Value   : NANDFLASHERR_NO_ERROR or
*                    NANDFLASHERR_TIMEOUT
* Comments         :
*    This function reads the ID from the NAND Flash
*    using the NFC module.
*
*END*----------------------------------------------------------------------*/

uint_32 nfc_read_ID
   (
      /* [IN] the NAND flash information */
      IO_NANDFLASH_STRUCT_PTR nandflash_ptr,

      /* [IN] where to store ID */
      uchar_ptr               to_ptr,

      /* [IN] the amount of ID bytes */
      _mem_size               size
   )
{ /* Body */

    uint_32 i;
    unsigned char tmpData;
		
    Nand_EnableCS(1);
   
    *CmdPort = NANDFLASH_CMD_READ_ID;
    *AddrPort = 0x00;

//	if(Nand_WaitIOReady() == NANDFLASHERR_TIMEOUT)
//	{
//		Nand_EnableCS(0);
//		return NANDFLASHERR_TIMEOUT;
//	}
   
	for (i = 0; i < size; i++)
	{
       to_ptr[i] = *DataPort;
	}
    
    tmpData = *DataPort;

   Nand_EnableCS(0);
	
   return NANDFLASHERR_NO_ERROR;
} /* Endbody */

/*FUNCTION*-------------------------------------------------------------------
*
* Function Name    : nfc_ioctl
* Returned Value   : TRUE if successful
* Comments         :
*    nfc ioctl function
*
*END*----------------------------------------------------------------------*/
_mqx_int nfc_ioctl
   (
      /* [IN] the handle returned from _fopen */
      IO_NANDFLASH_STRUCT_PTR handle_ptr,

      /* [IN] the ioctl command */
      _mqx_uint               cmd,

      /* [IN] the ioctl parameters */
      pointer                 param_ptr
   )
{ /* Body */
    _mqx_uint result = MQX_OK;

    switch(cmd) 
	{
        case NANDFLASH_IOCTL_GET_ID:
            /* Get the NAND Flash ID */
            if ((nfc_read_ID(handle_ptr, param_ptr, 4)) == NANDFLASHERR_NO_ERROR)
            {
                result = MQX_OK;
            }
            else
            {
                result = IO_ERROR_INVALID_IOCTL_CMD;
            }
            break;
        default:
            break;
    }
    return result;
}

/* EOF */
